<?php
// Conexão com o banco
$conn = new mysqli("localhost", "root", "senaisp", "escola");

// Verifica conexão
if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

// Consulta os clientes
$result = $conn->query("SELECT * FROM cliente");

echo "<h2>Lista de Clientes</h2>";
echo "<a href='form_cliente.html'>➕ Novo Cliente</a><br><br>";

if ($result->num_rows > 0) {
    echo "<table border='1' cellpadding='8' cellspacing='0'>";
    echo "<tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Endereço</th>
            <th>Estado</th>
            <th>Cidade</th>
            <th>Ações</th>
          </tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['id']}</td>
                <td>{$row['nome']}</td>
                <td>{$row['endereco']}</td>
                <td>{$row['estado']}</td>
                <td>{$row['cidade']}</td>
                <td>
                    <a href='edit.php?id={$row['id']}'>✏️ Editar</a> | 
                    <a href='delete.php?id={$row['id']}' onclick=\"return confirm('Deseja excluir este cliente?');\">🗑️ Excluir</a>
                </td>
              </tr>";
    }

    echo "</table>";
} else {
    echo "<p>Nenhum cliente cadastrado ainda.</p>";
}

$conn->close();
?>
