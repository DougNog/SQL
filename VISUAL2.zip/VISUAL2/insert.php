<?php
// Obtém os dados do formulário com validação básica
$nome     = isset($_POST['nome']) ? trim($_POST['nome']) : '';
$endereco = isset($_POST['endereco']) ? trim($_POST['endereco']) : '';
$estado   = isset($_POST['estado']) ? trim($_POST['estado']) : '';
$cidade   = isset($_POST['cidade']) ? trim($_POST['cidade']) : '';

// Verifica se todos os campos foram preenchidos
if (empty($nome) || empty($endereco) || empty($estado) || empty($cidade)) {
    die("Por favor, preencha todos os campos antes de enviar o formulário.");
}

// Conexão com o banco
$conn = new mysqli("localhost", "root", "senaisp", "escola");

// Verifica a conexão
if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

// Prepara o comando SQL (protege contra SQL Injection)
$stmt = $conn->prepare("INSERT INTO cliente (nome, endereco, estado, cidade) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $nome, $endereco, $estado, $cidade);

// Executa o comando
if ($stmt->execute()) {
    echo "<h3>✅ Dados salvos com sucesso!</h3>";
    echo "<a href='listar_clientes.php'>Voltar à lista</a>";
} else {
    echo "Erro ao salvar: " . $stmt->error;
}

// Fecha a conexão
$stmt->close();
$conn->close();
?>
