<?php
// Conexão com o banco
$conn = new mysqli("localhost", "root", "senaisp", "escola");

// Verifica se houve erro na conexão
if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}

// Obtém os dados do formulário
$id = $_POST['id'];                // o campo hidden do formulário
$nome = $_POST['nome'];            // campo "nome"
$endereco = $_POST['endereco'];    // campo "endereco"
$estado = $_POST['estado'];        // campo "estado"
$cidade = $_POST['cidade'];        // campo "cidade"

// Monta o SQL de atualização
$sql = "UPDATE cliente 
        SET nome = '$nome', 
            endereco = '$endereco', 
            estado = '$estado', 
            cidade = '$cidade'
        WHERE id = $id";

// Executa o comando
if ($conn->query($sql) === TRUE) {
    echo "<p>Registro atualizado com sucesso!</p>";
    echo "<a href='listar.php'>Voltar à lista</a>"; // você pode alterar para 'index.html' se quiser
} else {
    echo "Erro ao atualizar: " . $conn->error;
}

// Fecha a conexão
$conn->close();
?>
