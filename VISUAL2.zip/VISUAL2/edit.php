<?php
// Conexão com o banco de dados
$conn = new mysqli("localhost", "root", "senaisp", "escola");

// Verifica se houve erro na conexão
if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}

// Obtém o ID pela URL e valida
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Busca o registro correspondente
$result = $conn->query("SELECT * FROM cliente WHERE id = $id");

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    die("Usuário não encontrado!");
}
?>

<!-- Formulário de atualização -->
<form action="update.php" method="POST">
    <input type="hidden" name="id" value="<?php echo $row['id']; ?>"> <!-- Corrigido: campo hidden precisa ser o ID -->

    Nome: <input type="text" name="nome" value="<?php echo $row['nome']; ?>"><br>
    Endereço: <input type="text" name="endereco" value="<?php echo $row['endereco']; ?>"><br>
    Estado: <input type="text" name="estado" value="<?php echo $row['estado']; ?>"><br>
    Cidade: <input type="text" name="cidade" value="<?php echo $row['cidade']; ?>"><br>
    
    <input type="submit" value="Atualizar">
</form>
